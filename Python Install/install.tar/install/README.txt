Setup Instruction for Python Environment

1. Run the command "idev -rtx" to open a new session on a GPU-enabled node
2. Make sure each of the following modules are installed:
autotools/1.2   
cmake/3.20.3   
pmix/3.1.4   
hwloc/1.11.12   
xalt/2.10.27   
TACC  
git/2.24.1   
gcc/6.3.0   
cuda/10.0 (g)  
cudnn/7.6.2 (g)  
nccl/2.4.7 (g)

Note: You can use the command "module load x" to install a module named x.

3. Run "python_install.sh"
4. Add the following to the "~/.bashrc" file in $HOME. These entries must be placed in Section 2 on the Frontera compute environment.
 
export PATH=$HOME/python/Python-3.7.9/:$PATH
export PYTHONPATH=$HOME/python/Python-3.7.9
export PATH=$HOME/.local/bin:$PATH
export PATH=$HOME/python/bin:$PATH

5. Run "python_package_install.sh"

You should now have all necessary python packages installed.
