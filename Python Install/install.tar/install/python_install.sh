# Download and build python from source
mkdir python
cd python
wget https://www.python.org/ftp/python/3.7.9/Python-3.7.9.tgz
tar zxfv Python-3.7.9.tgz
rm Python-3.7.9.tgz
cd Python-3.7.9
./configure --prefix=$HOME/python
make && make install



