source ~/.bashrc
wget --no-check-certificate https://bootstrap.pypa.io/get-pip.py -O - | python - --user
source ~/.bashrc
python -m pip install -r requirements.txt
 
